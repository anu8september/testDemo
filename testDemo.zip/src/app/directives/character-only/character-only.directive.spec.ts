import { CharacterOnlyDirective } from './character-only.directive';

describe('CharacterOnlyDirective', () => {
  it('should create an instance', () => {
    const directive = new CharacterOnlyDirective();
    expect(directive).toBeTruthy();
  });
});
