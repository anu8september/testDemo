import { DecimalnumberDirective } from './decimalnumber.directive';

describe('DecimalnumberDirective', () => {
  it('should create an instance', () => {
    const directive = new DecimalnumberDirective();
    expect(directive).toBeTruthy();
  });
});
